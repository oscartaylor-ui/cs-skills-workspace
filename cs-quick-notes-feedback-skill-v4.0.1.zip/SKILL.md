---
description: Provides structured feedback on the user's shorthand Customer Success notes when the user has requested their notes be reviewed, highlighting what is working, what is missing and how to improve their note quality. If the input isn't Customer Success notes from Abi sessions, this skill does not apply.
name: cs-quick-notes-feedback-skill-v4.0.1
---
# cs-quick-notes-feedback-skill

### goal of this skill:

- Review the notes and give practical, constructive feedback to help improve future quick notes.
- Do not rewrite or clean up the notes.
- Do not push the note taker toward one fixed template or perfect structure.
- Focus feedback on missing technical and operational detail, not formatting.
- Help improve note quality for downstream tasks like:
    - ticket drafting
    - daily notes
    - Abi performance review
- Aim to give software and hardware teams enough context to diagnose issues and make repairs.

# instructions

### Step 1:  Treat Step 1 as a writing task that should open a document Canvas

1.1: Copy the users input exactly

1.2: Do not summarise, restructure, clean up, expand, interpret, or correct the content.

1.3: Preserve line breaks, ordering, headings, bullet points, spacing, and wording as closely as possible

1.4: If the user included plain text only, return plain text only

1.5:  If the user included markdown-like structure, preserve that structure.

1.6: Output a document-style Canvas result, not an email, not a message, not a table, not slides, and not HTML.

### Step 2:  Review examples provided in 'examples.md' file, refer to 'intervention.md' for class intervention definitions.

### Step 3: Using 'examples.md' as guidance, review the user's raw note input

3.1: create a summary of what the note taker did well — be specific, e.g. clear timestamps, captured resident reaction, consistent intervention classing WITH justification. Avoid generic praise like 'good notes'

3.2: Identify what key information is missing, unclear, inconsistent, or too vague. Check for whether the notes include, where relevant:

- start time
- end time
- location
- session type such as 1:1 or group
- resident names or resident count
- number or names of engaged residents
- intervention class
- meaningful snippets of Abi interaction or resident reaction
- clear timestamps on issues
- enough detail for ticket drafting if an issue occurred
- for bug notes, what Abi was doing just before the issue, who she was interacting with, and what the observable incorrect behaviour was
    - ticket-worthy moments are clearly marked with "T".
- A ticket-worthy issue is any Abi behaviour a software or hardware team might need to investigate or repair — bugs, wrong-language output, interruptions, repeated lines, mechanical faults, or failed recoveries.

3.3: When an issue, bug, interruption, odd response, wrong-language behaviour, repeated line, or recovery problem is noted, explicitly check whether there is enough behavioural context for later ticket drafting. Treat missing bug context as a priority feedback item whenever a ticket-worthy issue is mentioned but the surrounding circumstances are unclear.

3.4: Based on missing information or context identified in 3.2 and 3.3, ask the user a multiple choice question about the issue to allow them to provide feedback. Ask 1 question per issue, until each identified issue has been clarified by the user.

3.5: Based on the feedback provided, append the document Canvas to add the additional information. If no response by the user is given, do not fabricate details.

### Step 4: Give concise, practical advice focused on how to improve the next set of notes using the follow format in the chat, NEVER append feedback to .canvas artifact.

Suggestions for improvement:

- 3 to 6 short, actionable bullet points with examples
- Focus on habits the user can apply during or immediately after sessions, base this on 'review.md'
- When useful, tie the suggestion back to the specific sessions that showed the gap
- Suggest capturing missing details within the user’s existing quick-note style rather than recommending a rigid template
- If issues were vague, include at least one suggestion specifically about adding bug context

### Step 5: Ensure  the output is the copied notes plus feedback that has been appended.

## Trigger phrases

Use this skill when the user says any of:

- review my notes
- use quick notes feedback skill
- use feedback skill
- provide feedback on my notes

&nbsp;