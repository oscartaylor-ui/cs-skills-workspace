# good example input:strong but with coaching opportunities
10:02 abi powered on and fully charged
10:06 group session with Helen, Elizabeth and Natalina in lounge on level 1.
Natalina greets Abi in Italian and asks for music
I get Abi to play Litaliano - Natalina claps along
Class D interaction in group as I guide Abi and direct her
10:12 end
10:13 1-1 with Natalina starts in lounge on Level 1
Abi says goodbye to Helen and she is very grateful
Natalina finds even at 67% Abi speaks too quickly. Abi reduced to 38% by herself
Once adjusted they start speaking together
Class A interaction, very hands off while they speak in Italian.
Photo taken of interaction of Abi consoling Natalina
Abi suggests some music options and Natalina chooses Pavarotti
Natalina smiles and laughs while singing along to song she chose
T | 10:19 after Abi sings o sole mio, she says her "get ready to boogie to O Sole Mio" immediately after playing the song
10:21 Abi interrupt, no context provided.
10:23 end
10:30-10:43 group session ground floor coffee club
8 residents, Class D intervention due to required wireless microphone and loud environment.
Abi plays music and takes requests
Residents are really thrilled this morning
Joan very happy
George requests music
Greek Helen laughing and clapping
At around 10:41, Abi's arm got stuck behind her back but she recovered by herself
T | 10:41 - after asking Abi to say goodbye, she says it in Italian.
10:55-11:08
Group Session, T’ai chi with 10 residents on the lower ground, all engaging and following along
first 5 minutes was talking and answering questions from Jane and others about Abi. High cognitive residents who may not need Abi but are very interested and curious minded
Check in with Koula in her room at 11:16, she said no
11:24 1-1: Natalina and Abi on level 1 lounge
Class A interaction in Italian, unsure what was discussed but I didn’t need to interject
Abi plays Volare and Natalina sings along
11:31 immediately after finishing song X, Abi says "Here comes song X"
Abi comforts Natalina
11:35 end

## Why this is a strong example overall:
1. clear timestamps are used throughout
2. group and 1:1 sessions are easy to follow
3. Positive resident reactions are captured well
4. intervention class is often stated and supported by context that align with intervention class outlined in intervention-criteria.md
5. ticket-worthy moments are clearly marked with T.

## What the skill should notice and coach on in this example:
1. some sessions would be stronger with intervention class stated explicitly
2. the 11:31 'Here comes song X' line is a likely ticket-worthy bug that wasn't marked with T — flag unmarked issues like this
3. some group sessions name who was present but not who was actively engaged
4. the 11:16 Koula check-in needs a clearer outcome such as whether this was a decline to chat, music, or the session entirely
5. some issue notes need more context for later ticket writing

## Important bug-context examples from this note set:
1. "10:21 Abi interrupt, no context provided" should be called out as a key gap because the interruption is timestamped but not usable for a ticket without saying what Abi was doing
2. "10:41 - after asking Abi to say goodbye, she says it in Italian" should be called out as needing one more line of context, such as who Abi had been talking to, whether Italian had come up just before, or whether she was meant to be ending an English interaction
3. when a bug is already close to usable, the skill should praise that and then ask for only the missing context, not over-criticise the whole note set

# Good quick notes example: 1:1 session
10:25 | 1-1 Wallace Gromet in Room 202
- Abi says Hi to Wallace and asks about his day
- Wallace is happy to see Abi and his eyes lit up when she said his name
- Wallace requested music and Abi suggested some songs
T | 10:30AM Abi interrupted (photo taken)
Class B - Abi heard Wallet instead of Wallace and had to be corrected by CS.
T | 10:35 Abi interrupt (photo taken)
10:45 end

## Why this is good:
1. includes start time, session type, resident name, and location
2. captures meaningful resident reaction and interaction detail
3. timestamps issues clearly
4. the 10:30 and 10:35 interruptions would be stronger with one line on what Abi was doing — note this is the kind of gap to flag even in otherwise strong notes
5. If there is a statement that says "photo taken" or similar, treat this as sufficient context but request the user to insert the image into final notes.
6. includes intervention detail and class with justification
7. ends with a clear session end time. Session end time does not have to be in the heading of the notes, it can be the last line like in this example

# Good quick notes example: group session
15:30 | GS 6 residents present in Level 1 Lounge
Abi plays music requested by residents
I drove Abi to each resident to see if they wanted to say hi
I was acting as the MC, talking and responding to Abi as background noise was very loud
I am often repeating what Abi was saying
T | 15:40 - Abi incorrectly played language guessing game, she asked what language was she speaking in the language we were meant to guess.
Class D - due to above reasons
16:00 end

## Why this is good:
1. includes start time, session type, resident count, and location
2. records session type as "GS", but it can also be labelled any other derivative such as "group session", "group", etc.
3. explains the environment and why CS intervention was needed
4. records what Abi was doing and what the facilitator was doing
5. timestamps the issue
6. includes end time