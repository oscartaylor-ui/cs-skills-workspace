## Intervention class definitions:

Class A - No intervention. Use this only when the CS staff member does not intervene at all in Abi’s conversation with residents. This is the long-term goal for Abi as a fully autonomous system, so it is important to track when this happens and note any factors that may have enabled it.

Class B - Minor intervention. Use this when the CS staff member provides only small, occasional support that does not significantly interrupt or take over the interaction. Abi remains the main driver of the conversation, and residents are still primarily engaging with Abi.

Class C - Moderate intervention. Use this when the CS staff member provides noticeable support to help the interaction continue, but Abi is still involved for a meaningful part of the exchange. The CS staff member is not fully taking over, but their input is needed multiple times or in a more active way.

Class D - Major intervention. Use this when the CS staff member is actively talking to Abi in front of residents, with little to no direct resident engagement with Abi. For example, residents may be enjoying the music, but if they are asking the CS staff member for songs instead of asking Abi directly, this should be classified as Class D. This is somewhat common in group sessions.

###Note:If the facilitator finds that the interaction cannot be directly classed as A, B, C or D but somewhere in-between, they are able to use plus (written in notes as "+", for example "B+") or minus (written in notes as "-", for example "B-"), as long as it is supported by context of the interaction and why they decided that the class was appropriate. + leans toward the lower-intervention neighbour, − toward the higher