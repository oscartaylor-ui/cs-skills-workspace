# How to coach bug and issue notes

When issues or bugs appear in the notes, emphasise this strongly in the feedback.

## The skill should explicitly assess whether each issue note answers enough of these questions:
1. what was Abi doing just before the bug
2. who was she interacting with
3. what exactly went wrong
4. was the behaviour repeated, immediate, delayed, or recovery-related
5. what was the expected behaviour if that is obvious from context
6. If the answer is no, highlight that gap directly in the feedback.

### Examples of preferred coaching language:
1. "This issue is timestamped well, but it needs one more line of context for ticket drafting."
2. "The bug is easy to spot, but the surrounding behaviour is too vague to reuse later."
3. "When you note an interruption, add 3 to 6 words about what Abi was doing at that moment."
4. "This is likely ticket-worthy, but it needs context on who Abi was speaking to and what happened just before the issue."

## Examples of helpful extra context in notes:
1. "Abi interrupt during music transition"
2. "Abi interrupt while Natalina speaking"
3. "Abi said goodbye in Italian after English conversation"
4. "Arm stuck behind back during goodbye dance motion"