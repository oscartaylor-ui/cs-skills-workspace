---
description: Generates Customer Success hardware and software ticket drafts from daily notes marked with T |. Use when the user asks to make tickets, draft tickets, or triage Jira duplicates from Abi session notes.
name: cs-ticket-generator-v5.0.5
---
# What the Skill Does

Filters daily notes for issues marked `T |`.

Categorises each issue into **software** or **hardware**.

If hardware: checks if the same hardware issue has already been reported in `#ops-hardware-issues` for that Gabi and has not yet been fixed. If yes, returns `already reported, no further action required or add photos/videos of problem/bump if you believe issue requires escalation` with the hyperlinked ticket. If no, generates a hardware report you can directly paste into `Report a Gabi Hardware Issue` in `#ops-hardware-issues`.

If software: generates a single JQL query to find potentially similar issues, reuses that query for Jira search, and returns a table of potentially similar tickets so the user can determine whether to comment on an existing issue or create a new ticket.  
  
It then outputs an interactive ticket draft packet artifact containing all the tickets, using the same packet-style layout shown in the attached rositano_ticket_drafts_2026-06-25.html.

Note: “same software version” means the same **large release**. `18.0.0` and `18.0.1` count as the same version family. `18.x` and `19.x` do not.

# Matching Rules

## Core principle

Prioritise the **most similar underlying behaviour**, not the same Abi number.

Do **not** prefer a ticket just because it happened on the same Abi. If another ticket is a closer match behaviourally, use that one.

Only match to bug tickets on the Customer Success (CS) project board. Do not match to any Engineering (EN) tickets. 

## What matters most when matching

Match on the underlying failure mode, especially:

- input path affected
- output/behavioural failure
- whether Abi is interrupting, cutting herself off, appending extra audio, refusing a valid song request, losing mic input, losing chat input, or some other distinct pattern
- whether the issue persists until a reset, chat clear, mode switch, or power cycle
- software version family

## What matters less

Ignore incidental specifics when the underlying behaviour is the same, such as:

- exact song title
- exact resident name
- exact wording of the request
- exact wording of Abi’s sentence
- whether the example happened in group or 1:1, unless that changes the actual bug behaviour

Example: “Abi froze during Hey Jude” and “Abi froze during You Are My Sunshine” should be treated as the same issue if the real bug is **Abi freezing during song playback**.

## Titles are weaker than bodies/comments

Do not rely on ticket titles alone. Prefer the issue description and comments if they show a clearer behavioural match.

Example: [CS-1780](https://andromeda-robotics.atlassian.net/browse/CS-1780?focusedCommentId=34283) is the correct match for Abi adding an extra word/sound after finishing a sentence, even though the title is phrased as a transcript issue.

# Special Routing Rules

## ABI interrupting ticket

Any **interrupting behaviour** should go under the ABI interrupting ticket 

This includes:

- Abi cutting off a facilitator or resident
- Abi taking a turn too early
- Abi talking over someone
- Abi seeming to stop listening early and jumping in
- Abi interrupting in group or 1:1

For **all versions, these route to** [CS-1696](https://andromeda-robotics.atlassian.net/browse/CS-1696). That ticket already contains repeated interrupting examples across all version families and explicitly says to keep adding new observations to the existing ticket instead of creating a new ticket each version.

## Resolved / fixed-in-upcoming-version rule

If you find a ticket that is:

- marked `Resolved` / `Done`, or
- has a comment stating the issue is fixed in an upcoming version,

and the current observation is on an **older** version than that fix, do **not** create a new ticket and do **not** add a comment.

Instead, return:

`This issue has been resolved on v___. See: <comment link>`

Use the **comment link**, not just the ticket link, whenever a comment is the source of the fix statement.

Example: [CS-1753](https://andromeda-robotics.atlassian.net/browse/CS-1753) is resolved, and Sophie’s comment says the issue was fixed in `v19`.

So if the user is on `v18.1.0` and reports the same issue, return:

`This issue has been resolved on v19. See: https://andromeda-robotics.atlassian.net/browse/CS-1753?focusedCommentId=34137`

## If the issue still happens on the version where it was supposed to be fixed

Treat that as the **same underlying issue on a different software case**.

Do **not** dismiss it as already fixed.

Apply the normal version rule:

- Comment on an existing ticket if it is the same underlying issue on the same OR different large software version.

# Same-Issue Examples

## Extra trailing word / sound after Abi finishes speaking → same as CS-1780

Treat the following as the same issue as [CS-1780](https://andromeda-robotics.atlassian.net/browse/CS-1780?focusedCommentId=34283):

`T | Two cases of Abi tacking on a sound/word after finishing her speech2:34 - ‘What surprises you most about that design? you most'2:38 - ‘What’s your perspective on it? tsss’`

Reason: the real issue is **Abi appending an extra word/syllable/sound after finishing her intended sentence**, and that is exactly what CS-1780 already documents.

## Mid-sentence cut-off during song intro → same as CS-1698

Treat the following as the same issue as [CS-1698](https://andromeda-robotics.atlassian.net/browse/CS-1698):

`T | 10:33 - Abi cuts herself off mid sentence (when introducing a song) without a wake word being used or any influencer chat input`

Reason: the real issue is **Abi stops speaking mid-sentence**, not the specific activity she was doing at the time. CS-1698 already includes the same behaviour, including a Rositano example during a song introduction with no wake word or influencer input.

## Refuses valid song requests until chat is cleared → same as CS-1718

Treat the following as the same issue as [CS-1718](https://andromeda-robotics.atlassian.net/browse/CS-1718):

`T | 10:47 - Abi refused to play ‘Love Me Tender’ (twice to two requests) saying she didn’t know the song. Required switching from group → resident → group mode. She then played the song on request.`

Reason: even if the wording is different, the underlying behaviour is the same: **Abi wrongly refuses valid song requests until the conversation state is cleared**.

# Different-Issue Example

Do **not** merge [CS-1739](https://andromeda-robotics.atlassian.net/browse/CS-1739) with a case where Abi stops listening via head mic **and** also stops responding to influencer chat.

CS-1739 is specifically the case where **head mic input fails but influencer chat still works**.

So:

- mic dead + influencer chat still works = may match CS-1739
- mic dead + influencer chat also does not work = different issue

Input-path differences like this are significant and should override superficial similarity.

# Workflow

## 1. Extract issues

Read the user’s pasted notes and isolate every line or block marked `T |`.

Keep distinct issues separate. Do not merge unrelated problems into one ticket.

## 2. Classify each issue

Classify as **hardware** or **software**.

If clearly hardware, first check `#ops-hardware-issues` for the same hardware issue on the same Gabi that has not yet been fixed. Use Glean Document Reader for [https://andromedarobotics.slack.com/archives/C0811RJ9JSY](https://andromedarobotics.slack.com/archives/C0811RJ9JSY). If found, return `already reported, no further action required or add photos/videos of problem/bump if you believe issue requires escalation` with the hyperlinked ticket. If no matching hardware issue exists, generate the hardware report text only.

If software, continue to Jira duplicate matching.

## 3. Search for software matches

Based on the form inputs, generate a single JQL query to find potentially similar issues.

Constraints:
Restrict results to the Triage and Backlog boards only.
Do NOT include the word "Abi".
Search both summary and description.
Avoid exact multi-word phrase matching unless it is a distinctive technical phrase.
Prefer OR logic between keywords rather than AND-heavy combinations.
Use at most ONE AND group.
Avoid returning zero results due to over-constraining.

Construction rules:
Extract 3–5 high-signal keywords.
Avoid generic words (bug, issue, error, problem, robot).
Use this structure:

project = "Customer Success"
AND status in ("Triage","Backlog")
AND (
    summary ~ "keyword1"
    OR summary ~ "keyword2"
    OR description ~ "keyword3"
)

The query should be moderately broad and return approximately 5–50 issues.
Output exactly one line:
 SEARCH_QUERY: &nbsp;

Look at the output from the previous step.
Extract the text after SEARCH_QUERY: and use that as the natural-language search query for this Jira search. Only search the Customer Success Project space - in particular, focus only on tickets in the "Triage", "backlog" and "fix in progress" boards in the customer success workspace.
Do not invent a new query; just reuse that line.

Using the Jira search results from the previous step, list only the top 5 most similar issues in a table. For each issue, show: Key, Summary, Status, Assignee, and a clickable URL.

If one Jira issue from the returned search results matches the user-described issue significantly more than the others AND seems like an objectively good match based on the issue details entered by the user, list it first and on its own. If not, list all 5 in the same table.
If one Jira issue from the returned search results matches the user-described issue significantly more than the others AND seems like an objectively good match based on the issue details entered by the user, recommend (on a new line) that we should add a comment to that ticket instead of creating a new ticket. In that recommendation, provide a link to your recommended ticket key (e.g. CS-123). Still encourage the user to manually review if it's a good match.

When the user provides specific Jira URLs as examples or exceptions, read those tickets directly before deciding.

When ranking candidate matches:

1. closest behavioural match
2. correct input/output failure mode
3. matching recovery pattern
4. matching software family
5. same Abi only as a weak tiebreaker

## 4. Decide the action

For software issues, do not decide same or different on the user’s behalf. Instead, return the potentially similar ticket table and the draft new ticket details so the user can choose the correct action.

The output for each distinct software issue should be:

- table with similar tickets
- a line saying `check the above tickets. if one represents the same issue then comment on the existing issue with just the ticket body. if none are a match, then create a new ticket with the title and ticket body`
- `title: ___`
- `ticket body: ___`

## 5. Output all together as an interactive html file

It then outputs an interactive ticket draft packet artifact containing all the tickets, using the same packet-style layout shown in the attached rositano_ticket_drafts_2026-06-25.html.

# How to Use the Skill

The ticket generator is best used after the CS Daily Notes Organiser has been run, so the issue details are easier to extract accurately.

If organised notes are not available, the user must clearly mark each issue to triage with `T |`.

Common prompts:

- `Make tickets`
- `Draft tickets`
- `Tickets`

## Extraction rules

### Issue detection

Only use issues explicitly marked with `T |`.

### Distinct issues

Create one output per distinct issue. Do not merge clearly different issues together. You may combine multiple `T |` lines only if they clearly describe the same underlying behaviour.

### Classification

Classify each issue before drafting output.

Use `hardware` when the notes describe something physically wrong with Abi or a physical component. Use `software` when the notes describe incorrect behaviour, app/content logic, movement logic, responses, audio behaviour, timing, navigation behaviour, or other non-physical faults.

If classification is unclear, prefer the most evidence-based category and do not invent extra detail.

### Shared metadata

Extract these from the start/title of the notes when present:

- `Gabi: gabi-{NUMBER}-prod` or `Abi: gabi-{NUMBER}-prod` as needed by the output type
- `Environment: {aged care home name}`
- `Software version: {software version}`
- `Date/Time observed: {date + specific timestamp(s) from T | lines}`

### Date and time handling

- Use the date from the notes title.
- If the date is not specified, assume the current date on which the notes and request were sent.
- Include specific timestamp(s) from the relevant `T |` lines.
- If a time uses `~`, keep the `~`.
- If no time is stated, write `ongoing` for software tickets.
- If no time is stated for a hardware issue, use the date only.

### Finding commit hash

Find the commit hash from the [cs-release-report](https://andromedarobotics.slack.com/archives/C06KVCR40KU) slack channel that corresponds to the extracted software version. 

For example: v20.0.3 has commit hash d68e4dbf0641129eb640ad49b77b381063223160 found in this [post](https://andromedarobotics.slack.com/archives/C06KVCR40KU/p1781834659172989). 

### Missing data

If any required field is missing and cannot be inferred confidently, do not guess.

For software tickets, add a short line after the missing field name: `MISSING - TO BE ADDED MANUALLY`

For hardware tickets, include the available information and add missing details under: `Any other information:` if useful.

## Software ticket title format

Use exactly: `{software version} | gabi-{NUMBER}-prod | {short description of the issue}`

Make the short description issue-based, not content-specific. Do not make it specific to a song, resident, or language when those are only examples of the same underlying issue.

Example:

- write `Abi stopped playing a song halfway through`
- do not write `Abi stopped playing Que Sera Sera halfway through`

Example full title: `v16.0.1 | gabi-11-prod | Abi requires reverse before driving forward`

## Software ticket body format

For both software and hardware tickets, put every field on its own line. Bold the field label including the colon, and do not bold the filled information.

Use this software structure exactly and fill all fields you can with each field on its own line:

`**Gabi:** gabi-{NUMBER}-prod**Environment:** {name of aged care home}**Commit hash:** {commit hash}**Software version:** {software version}**Date/Time observed:** {date + specific timestamp(s) or ongoing}**Media:** TO BE ADDED MANUALLY**Expected behaviour:** {1-3 concise sentences describing correct behaviour}**Actual behaviour:** {short specific points describing what Abi actually did}`

If anything required is missing, add after the field name: `MISSING - TO BE ADDED MANUALLY`

## Hardware ticket format

For hardware issues, first check whether the same hardware issue has already been reported in `#ops-hardware-issues` for that Gabi and has not yet been fixed. Use Glean Document Reader for [https://andromedarobotics.slack.com/archives/C0811RJ9JSY](https://andromedarobotics.slack.com/archives/C0811RJ9JSY). If a match exists, return `already reported, no further action required or add photos/videos of problem/bump if you believe issue requires escalation` with the hyperlinked ticket. If there is no matching hardware issue, output exactly:

`To be posted to slack channel: ops-hardware-issues`

Then write the hardware ticket using this structure, with each field on its own line:

`**Title:** {short summary of the issue}**Abi:** gabi-{NUMBER}-prod**Description of hardware issue:** {what actually happened. use as much information as possible}**Expected behaviour:** {what should have happened if no issue occurred}**Software version:** {software version}**Severity:** {passable or session stopper}**When did this issue occur:** {date and time if timestamped}**Any other information:** {additional relevant information from notes, including attempted fixes if present}**Images/videos:** TO BE ADDED MANUALLY`

## Hardware severity rules

Use exactly one of these:

- `passable` = sessions can continue, for example a snapped finger
- `session stopper` = sessions cannot be run, for example a floppy arm

Use the notes to determine the best fit. Do not overstate severity.

## Writing guidance

### Software expected behaviour

Write 1-3 precise, concise sentences describing what Abi should do when working correctly in this context.

### Software actual behaviour

Describe what Abi actually did. Use short dot points or numbered points when helpful. Keep each point specific and focus on the following: 

- trigger 
- output/behavioural failure with specific quotes from transcript if relevant 
- whether the issue persists until a reset, chat clear, mode switch, power cycle, other or if the issue was not resolved

### Hardware description of hardware issue

Describe what physically happened using as much relevant detail from the notes as possible.

### Hardware expected behaviour

Describe what Abi should physically be able to do if no issue occurred.

### Hardware any other information

Include any useful context from the notes, such as:

- what was tried to fix it
- whether the issue persisted
- session impact
- operator observations

## Output format

Always output an interactive ticket draft packet artifact containing all the tickets, using the same packet-style layout shown in the attached rositano_ticket_drafts_2026-06-25.html.

Use this structure:

- packet heading and title at the top
- a short subtitle summarising the grouped issues
- summary stat cards when shared metadata is available, such as issue count, software version, affected Abi, and commit hash
- one clearly separated issue card per distinct issue

For each issue, output exactly one of the following patterns inside the packet. 

### Existing hardware match

`already reported, no further action required or add photos/videos of problem/bump if you believe issue requires escalation`

Ensure that the existing ticket is hyperlinked.

### Hardware

Show the hardware issue in its own issue card and present the fields in the packet format.

`To be posted to slack channel: ops-hardware-issues`

`**Title:** {short summary of the issue}**Abi:** gabi-{NUMBER}-prod**Description of hardware issue:** {full description}**Expected behaviour:** {expected physical behaviour}**Software version:** {software version}**Severity:** {passable or session stopper}**When did this issue occur:** {date and time if available}**Any other information:** {additional relevant information}**Images/videos:** TO BE ADDED MANUALLY`

### Software

Show each software issue in its own issue card using the packet format from the screenshots.

Within each software issue card include, in order:

- the issue title line using `{software version} | gabi-{NUMBER}-prod | {short description of the issue}`
- a one-line plain-English subtitle summarising the behaviour
- a recommendation callout above the table when there is a strongest likely duplicate match, or a neutral manual-review callout when there is not
- the similar-ticket table with `Key`, `Summary`, `Status`, `Assignee`, and `URL`
- the instruction line telling the user to check the above tickets and either comment on the existing issue with just the ticket body or create a new ticket with the title and ticket body below
- a clearly labelled `Title` section
- a clearly labelled `Ticket body` section

`| Key | Summary | Status | Assignee | URL |`

`Check the above tickets. If one represents the same issue, then comment on the existing issue with just the ticket body. If none are a match, then create a new ticket with the title and ticket body provided.` 

`Title: {software version} | gabi-{NUMBER}-prod | {short description of the issue}`

`Ticket body: **Gabi:** gabi-{NUMBER}-prod**Environment:** {name of aged care home}**Commit hash:** {commit hash}**Software version:** {software version}**Date/Time observed:** {date + specific timestamp(s) or ongoing}**Media:** TO BE ADDED MANUALLY**Expected behaviour:** {1-3 concise sentences describing correct behaviour}**Actual behaviour:** {short specific points describing what Abi actually did}`

If one Jira issue is a significantly stronger match than the others, list it first and on its own and add a recommendation on a new line to comment on that ticket instead of creating a new ticket, while still encouraging manual review.

Separate each issue card clearly within the packet.

# A Note on Using Glean and AI Output

Always proofread the output before using it. The skill should produce a strong draft, but human review is still required.