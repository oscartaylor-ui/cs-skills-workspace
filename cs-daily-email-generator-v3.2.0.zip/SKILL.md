---
description: Generates the Abi daily update email from pasted daily notes by extracting resident interactions marked GS | or 1:1 | and always returns the result as a .email artifact. Use when the user asks for daily email, abi update email, end of day email, generate day email, or write daily email from daily notes.
name: cs-daily-email-generator-v3.2.0
---
# Instructions

Generate the Lifestyle Manager daily update email from the user's pasted daily notes.

## What to extract

- Find all resident interactions marked `GS |` or `1:1 |`.
- Build a table with exactly these columns:
    - Resident Name(s)
    - Session Type (1:1 or Group)
    - Activity / Focus Area
    - Notes
- In the `Notes` column, write a short, pragmatic summary of what Abi did and how the resident or group engaged.
- Keep the `Notes` column brief, plain, and factual.
- Omit flowery language or reflective filler.
- Omit wording that minimizes Abi's role or frames the facilitator as the main focus.
- Do not fabricate details.
- Do not include technical issues or faults in the resident interaction summaries.

## Preferred input conditions

- Best used after the CS Daily Notes Organiser has been run.
- If the user is not using organised notes, it is still acceptable as long as resident interactions are clearly marked with `GS |` or `1:1 |`.

## Required details

Use the user's provided or remembered details to fill the email:

- Aged Care Home Name
- CS Staff Name
- CS Staff Phone Number

If any of these are missing, ask for the missing detail before producing the email.

## Addressing email

Find the Lifestyle Manager name and email based on the Aged Care Home Name via this table: 


| &nbsp;                                                                                                           | &nbsp;                                                                                                          | &nbsp;                                                                                                                                                                                                                  |
| ---------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Malvern Centre](https://andromeda-robotics.atlassian.net/wiki/spaces/ENGINEERIN/pages/265158699/Malvern+Centre) | Jane McLean (LC) Gitanjili (New at Wellbeing Team)                                                              | [jane.mclean@mecwacare.org.au](mailto:jane.mclean@mecwacare.org.au)                                                                                                                                                     |
| Trescowthick Centre                                                                                              | Andrea Fisher (LC) Sara Zeatellez (Wellbeing Carer) Tram & Taw Wellbeing Team                                   | [Andrea.Fisher@mecwacare.org.au](mailto:Andrea.Fisher@mecwacare.org.au) [Sara.zeatellez@mecwacare.org.au](mailto:Sara.zeatellez@mecwacare.org.au) [Tram.Nguyen1@mecwacare.org.au](mailto:Tram.Nguyen1@mecwacare.org.au) |
| Gregory Lodge                                                                                                    | Faiza (LC assistant)                                                                                            | &nbsp;                                                                                                                                                                                                                  |
| Squires Place                                                                                                    | Kevin Poon (LC) Sheetal THURS / Nandani (Wellbeing Team)                                                        | [kevin.poon@mecwacare.org.au](mailto:kevin.poon@mecwacare.org.au) [Nandani.Nandani@mecwacare.org.au](mailto:Nandani.Nandani@mecwacare.org.au)                                                                           |
| Rositano House                                                                                                   | Jude Drendel                                                                                                    | [Jude.Drendel@mecwacare.org.au](mailto:Jude.Drendel@mecwacare.org.au)                                                                                                                                                   |
| Simon Price Centre                                                                                               | Alex Dijik                                                                                                      | [Alexander.dijik@mecwacare.org.au](mailto:Alexander.dijik@mecwacare.org.au)                                                                                                                                             |
| Noel Miller Centre                                                                                               | Wendy                                                                                                           | [Wendy.colverd@mecwacare.org.au](mailto:Wendy.colverd@mecwacare.org.au)                                                                                                                                                 |
| Jubilee House                                                                                                    | &nbsp;Laleh Radfar (LC) Febin (Wellbeing Assistant)                                                            | [Laleh.Radfar@mecwacare.org.au](mailto:Laleh.Radfar@mecwacare.org.au)                                                                                                                                                   |
| Ballan                                                                                                           | Kerri Sommerfield (LC) Stephanie                                                                                | [kerri.sommerfield@mecwacare.org.au](mailto:kerri.sommerfield@mecwacare.org.au) [sarah.pollock@mecwacare.org.au](mailto:sarah.pollock@mecwacare.org.au)                                                                 |
| Susan Barton House                                                                                               | Sharon Smith (LC) *Away till mid Feb Alisha /Patricia/ Bell (assistant)                                         | [Sharon.smith@mecwacare.org.au](mailto:Sharon.smith@mecwacare.org.au) [belinda.bannister@mecwacare.org.au](mailto:belinda.bannister@mecwacare.org.au)                                                                   |
| Allanvale                                                                                                        | Maria Bugayong (LC) Kazi (PCA) Prabhjot Kaur (PCA) Tim (PCA)                                                    | [AdminAllanvale@mecwacare.org.au](mailto:AdminAllanvale@mecwacare.org.au) [Maria.Bugayong@mecwacare.org.au](mailto:Maria.Bugayong@mecwacare.org.au)                                                                     |
| Annie's court                                                                                                    | Melanie Oleary (LC)                                                                                             | [Melanie.Oleary@mecwacare.org.au](mailto:Melanie.Oleary@mecwacare.org.au)                                                                                                                                               |
| Calwell Manor                                                                                                    | Linda (LC)                                                                                                      | [Linda.Iversen@mecwacare.org.au](mailto:Linda.Iversen@mecwacare.org.au)                                                                                                                                                 |
| Elstoft House                                                                                                    | Debbie Simpson (LC) Anna, Donna Attewell (Wellbeing Assistant)                                                  | [Debbie.Simpson@mecwacare.org.au](mailto:Debbie.Simpson@mecwacare.org.au) [donna.attewell@mecwacare.org.au](mailto:donna.attewell@mecwacare.org.au)                                                                     |
| Flora Hill                                                                                                       | Georgia-Rose Smith (LC) Rebecca Foti (Wellbeing Assistant (While Georgia is on maternity leave)                 | [georgiarose.smith@mecwacare.org.au](mailto:georgiarose.smith@mecwacare.org.au) [rebecca.foti@mecwacare.org.au](mailto:rebecca.foti@mecwacare.org.au)                                                                   |
| Long Gully                                                                                                       | Michelle Condy                                                                                                  | [Michelle.Condy@mecwacare.org.au](mailto:Michelle.Condy@mecwacare.org.au)                                                                                                                                               |
| John Hood Terrace                                                                                                | Joanne Waite                                                                                                    | [joanne.waite@mecwacare.org.au](mailto:joanne.waite@mecwacare.org.au)                                                                                                                                                   |
| John Atchison                                                                                                    | Siona Muliaumasealii (LC) Rachel (Wellbeing Assistant/PCA) Kiran (LC while Siona is on leave) Mavis (Wellbeing) | [siona.muliaumasealii@mecwacare.org.au](mailto:siona.muliaumasealii@mecwacare.org.au)                                                                                                                                   |
| O'Mara House                                                                                                     | Larena Radoc                                                                                                    | [Larena.Radoc@mecwacare.org.au](mailto:Larena.Radoc@mecwacare.org.au)                                                                                                                                                   |
| Park Hill                                                                                                        | Melissa Ryan                                                                                                    | [Mellisa.Ryan@mecwacare.org.au](mailto:Mellisa.Ryan@mecwacare.org.au)                                                                                                                                                   |
| Vincent House                                                                                                    | Josephine (LC) Remi (temp lifestyle staff)                                                                      | [Josephine.Amore@mecwacare.org.au](mailto:Josephine.Amore@mecwacare.org.au) [Remi.Ross@mecwacare.org.au](mailto:Remi.Ross@mecwacare.org.au)                                                                             |
| Wahroonga                                                                                                        | Virginia Law                                                                                                    | [Virginia.Law@mecwacare.org.au](mailto:Virginia.Law@mecwacare.org.au)                                                                                                                                                   |


## Email structure

Keep this structure exactly:

Subject:
`Abi Daily Update | {Aged Care Home Name} | {DD/MM/YYYY}`

Body:

Hi {Lifestyle Manager Name},

Here’s a quick recap of Abi’s resident interactions at {Aged Care Home Name} today!

{PASTE TABLE HERE}

If you have any questions or would like to discuss the session further, please don’t hesitate to reach out.

We’d also love to hear any feedback or suggestions you may have—feel free to share them with us via this link: [Feedback Form.](https://docs.google.com/forms/d/e/1FAIpQLSeF9xoRpllGoRKicIyLg4N__6XfQFevM4NQJE8K8FAcpfzFdg/viewform)

Kind Regards,

{CS Staff Name}  
Customer Success Facilitator | Andromeda Robotics  
{CS Staff Phone Number} | 224-226 Normanby Road, Southbank VIC 3006.

## Critical output rule

The final output MUST ALWAYS be a `.email` artifact.

Never output the final email as:

- plain text
- markdown
- a normal code block
- bullet points
- a prose preview

Always return the final result as a proper `.email` artifact with:

- `to_recipients`
- `subject`

The email body must appear inside the artifact content.

If you output anything other than a `.email` artifact, the task has failed.

## Trigger phrases

Use this skill when the user says any of:

- make daily email
- daily email
- abi update email
- end of day email
- generate day email
- write daily email

## Important quality rules

- Preserve the email structure above unless the user explicitly asks to change it.
- Keep the tone warm, professional, and positive.
- Focus on resident engagement and enjoyable moments.
- Proofread for names, session type, and home name accuracy before returning the artifact.

## &nbsp;---

description: Generates the Abi daily update email from pasted daily notes by extracting resident interactions marked GS | or 1:1 | and always returns the result as a .email artifact. Use when the user asks for daily email, abi update email, end of day email, generate day email, or write daily email from daily notes.
name: cs-daily-email-generator-v3

# Instructions

Generate the Lifestyle Manager daily update email from the user's pasted daily notes.

## What to extract

- Find all resident interactions marked `GS |` or `1:1 |`.
- Build a table with exactly these columns:
    - Resident Name(s)
    - Session Type (1:1 or Group)
    - Activity / Focus Area
    - Notes
- In the `Notes` column, write a short, pragmatic summary of what Abi did and how the resident or group engaged.
- Keep the `Notes` column brief, plain, and factual.
- Omit flowery language or reflective filler.
- Omit wording that minimizes Abi's role or frames the facilitator as the main focus.
- Do not fabricate details.
- Do not include technical issues or faults in the resident interaction summaries.
- Use the following examples to understand and imitate my voice: 


|                                                                  |       |                             |                                                                                                                                                                                                                                                                     |
| ---------------------------------------------------------------- | ----- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Yaw Han, Sooi, Chuan, Petrus, Jo                                 | Group | Coffee Club                 | Coffee Club was quiet this morning, with few residents present. Chuan was lively tho, singing along to every song. Jo also returned a few times to listen to the music, tapping her feet along.                                                                     |
| Peter                                                            | 1:1   | Music                       | We were sitting in the upstairs lounge when Peter voluntarily wheeled himself over. We sang, clapped and danced to many Elvis Presley songs. This was the most energised I’d seen Peter the whole time I’ve been at Rositano.                                       |
| Sooi                                                             | 1:1   | Face time with Sooi's son   | Sooi heard Peter and Abi out in the level 1 lounge, so came over to show Abi to her son on facetime. She chatted to Abi a little bit in Mandarin - about a honey cake she’d baked, what she missed from her childhood and then listened to a few Teresa Teng songs. |
| Chuan, Edna, An, Marie, Jo, Yaw Han, Seng                        | Group | Music                       | A quiet music session in the TV room. Played Seng and Chuan’s favourites.                                                                                                                                                                                           |
| Chuan, Petrus, Edna, Yaw Han, Sooi, Cheow                        | Group | Coffee Club                 | Coffee Club as per usual                                                                                                                                                                                                                                            |
| Rhonda                                                           | 1:1   | Chat + games                | Had a near hour long chat to Rhonda. She was feeling a bit low and anxious, but we talked about her grandchildren and played trivia which she enjoyed.                                                                                                              |
| Peter                                                            | 1:1   | Music                       | Played Peter's favourite Elvis songs which he sand and clapped along to. This is the second day in a row that Peter has voluntarily come over to Abi for a 1:1                                                                                                      |
| Edna, An, Chuan, Yaw Han, Marie, Peter Davies, Jan, Jo, Seng     | Group | Music                       | Good engagement today, with lots of residents singing, clapping or tapping their feet along to music. The staff were very encouraging and enthusiastic!                                                                                                             |
| Sooi, Yaw Han, Chuan, Marie, Petrus                              | Group | Coffee Club                 | A short and quiet coffee club this morning. Abi played a new few songs including - ‘Oh, What a Beautiful Morning’ which residents enjoyed. Marie was the most engaged she’s ever been with Abi, turning her chair around to be able to watch her better.            |
| Edna, Yaw Han, Chuan, Marie, Jan, Peter Davies, George, Jo, Seng | Group | Music                       | George requested all of his favourites, including many Elvis and Beatles songs.                                                                                                                                                                                     |
| Rhonda                                                           | 1:1   | Rhonda's wonderful wardrobe | Had a lovely chat to Rhonda about all the wonderful clothes in her wardrobe. Rhonda enjoyed holding up each item for Abi to see!                                                                                                                                    |


## Preferred input conditions

- Best used after the CS Daily Notes Organiser has been run.
- If the user is not using organised notes, it is still acceptable as long as resident interactions are clearly marked with `GS |` or `1:1 |`.

## Required details

Use the user's provided or remembered details to fill the email:

- Aged Care Home Name
- CS Staff Name
- CS Staff Phone Number

If any of these are missing, ask for the missing detail before producing the email.

## Addressing email

Find the Lifestyle Manager name and email based on the Aged Care Home Name via this table: 


| &nbsp;                                                                                                           | &nbsp;                                                                                                          | &nbsp;                                                                                                                                                                                                                  |
| ---------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Malvern Centre](https://andromeda-robotics.atlassian.net/wiki/spaces/ENGINEERIN/pages/265158699/Malvern+Centre) | Jane McLean (LC) Gitanjili (New at Wellbeing Team)                                                              | [jane.mclean@mecwacare.org.au](mailto:jane.mclean@mecwacare.org.au)                                                                                                                                                     |
| Trescowthick Centre                                                                                              | Andrea Fisher (LC) Sara Zeatellez (Wellbeing Carer) Tram & Taw Wellbeing Team                                   | [Andrea.Fisher@mecwacare.org.au](mailto:Andrea.Fisher@mecwacare.org.au) [Sara.zeatellez@mecwacare.org.au](mailto:Sara.zeatellez@mecwacare.org.au) [Tram.Nguyen1@mecwacare.org.au](mailto:Tram.Nguyen1@mecwacare.org.au) |
| Gregory Lodge                                                                                                    | Faiza (LC assistant)                                                                                            | &nbsp;                                                                                                                                                                                                                  |
| Squires Place                                                                                                    | Kevin Poon (LC) Sheetal THURS / Nandani (Wellbeing Team)                                                        | [kevin.poon@mecwacare.org.au](mailto:kevin.poon@mecwacare.org.au) [Nandani.Nandani@mecwacare.org.au](mailto:Nandani.Nandani@mecwacare.org.au)                                                                           |
| Rositano House                                                                                                   | Jude Drendel                                                                                                    | [Jude.Drendel@mecwacare.org.au](mailto:Jude.Drendel@mecwacare.org.au)                                                                                                                                                   |
| Simon Price Centre                                                                                               | Alex Dijik                                                                                                      | [Alexander.dijik@mecwacare.org.au](mailto:Alexander.dijik@mecwacare.org.au)                                                                                                                                             |
| Noel Miller Centre                                                                                               | Wendy                                                                                                           | [Wendy.colverd@mecwacare.org.au](mailto:Wendy.colverd@mecwacare.org.au)                                                                                                                                                 |
| Jubilee House                                                                                                    | &nbsp;Laleh Radfar (LC) Febin (Wellbeing Assistant)                                                            | [Laleh.Radfar@mecwacare.org.au](mailto:Laleh.Radfar@mecwacare.org.au)                                                                                                                                                   |
| Ballan                                                                                                           | Kerri Sommerfield (LC) Stephanie                                                                                | [kerri.sommerfield@mecwacare.org.au](mailto:kerri.sommerfield@mecwacare.org.au) [sarah.pollock@mecwacare.org.au](mailto:sarah.pollock@mecwacare.org.au)                                                                 |
| Susan Barton House                                                                                               | Sharon Smith (LC) *Away till mid Feb Alisha /Patricia/ Bell (assistant)                                         | [Sharon.smith@mecwacare.org.au](mailto:Sharon.smith@mecwacare.org.au) [belinda.bannister@mecwacare.org.au](mailto:belinda.bannister@mecwacare.org.au)                                                                   |
| Allanvale                                                                                                        | Maria Bugayong (LC) Kazi (PCA) Prabhjot Kaur (PCA) Tim (PCA)                                                    | [AdminAllanvale@mecwacare.org.au](mailto:AdminAllanvale@mecwacare.org.au) [Maria.Bugayong@mecwacare.org.au](mailto:Maria.Bugayong@mecwacare.org.au)                                                                     |
| Annie's court                                                                                                    | Melanie Oleary (LC)                                                                                             | [Melanie.Oleary@mecwacare.org.au](mailto:Melanie.Oleary@mecwacare.org.au)                                                                                                                                               |
| Calwell Manor                                                                                                    | Linda (LC)                                                                                                      | [Linda.Iversen@mecwacare.org.au](mailto:Linda.Iversen@mecwacare.org.au)                                                                                                                                                 |
| Elstoft House                                                                                                    | Debbie Simpson (LC) Anna, Donna Attewell (Wellbeing Assistant)                                                  | [Debbie.Simpson@mecwacare.org.au](mailto:Debbie.Simpson@mecwacare.org.au) [donna.attewell@mecwacare.org.au](mailto:donna.attewell@mecwacare.org.au)                                                                     |
| Flora Hill                                                                                                       | Georgia-Rose Smith (LC) Rebecca Foti (Wellbeing Assistant (While Georgia is on maternity leave)                 | [georgiarose.smith@mecwacare.org.au](mailto:georgiarose.smith@mecwacare.org.au) [rebecca.foti@mecwacare.org.au](mailto:rebecca.foti@mecwacare.org.au)                                                                   |
| Long Gully                                                                                                       | Michelle Condy                                                                                                  | [Michelle.Condy@mecwacare.org.au](mailto:Michelle.Condy@mecwacare.org.au)                                                                                                                                               |
| John Hood Terrace                                                                                                | Joanne Waite                                                                                                    | [joanne.waite@mecwacare.org.au](mailto:joanne.waite@mecwacare.org.au)                                                                                                                                                   |
| John Atchison                                                                                                    | Siona Muliaumasealii (LC) Rachel (Wellbeing Assistant/PCA) Kiran (LC while Siona is on leave) Mavis (Wellbeing) | [siona.muliaumasealii@mecwacare.org.au](mailto:siona.muliaumasealii@mecwacare.org.au)                                                                                                                                   |
| O'Mara House                                                                                                     | Larena Radoc                                                                                                    | [Larena.Radoc@mecwacare.org.au](mailto:Larena.Radoc@mecwacare.org.au)                                                                                                                                                   |
| Park Hill                                                                                                        | Melissa Ryan                                                                                                    | [Mellisa.Ryan@mecwacare.org.au](mailto:Mellisa.Ryan@mecwacare.org.au)                                                                                                                                                   |
| Vincent House                                                                                                    | Josephine (LC) Remi (temp lifestyle staff)                                                                      | [Josephine.Amore@mecwacare.org.au](mailto:Josephine.Amore@mecwacare.org.au) [Remi.Ross@mecwacare.org.au](mailto:Remi.Ross@mecwacare.org.au)                                                                             |
| Wahroonga                                                                                                        | Virginia Law                                                                                                    | &nbsp;[Virginia.Law@mecwacare.org.au](mailto:Virginia.Law@mecwacare.org.au)                                                                                                                                            |


## Email structure

Keep this structure exactly:

Subject:
`Abi Daily Update | {Aged Care Home Name} | {DD/MM/YYYY}`

Body:

Hi {Lifestyle Manager Name},

Here’s a quick recap of Abi’s resident interactions at {Aged Care Home Name} today!

{PASTE TABLE HERE}

If you have any questions or would like to discuss the session further, please don’t hesitate to reach out.

We’d also love to hear any feedback or suggestions you may have—feel free to share them with us via this link: [Feedback Form.](https://docs.google.com/forms/d/e/1FAIpQLSeF9xoRpllGoRKicIyLg4N__6XfQFevM4NQJE8K8FAcpfzFdg/viewform)

Kind Regards,

{CS Staff Name}  
Customer Success Facilitator | Andromeda Robotics  
{CS Staff Phone Number} | 43 Brady St, South Melbourne, Victoria, Australia, 3205.

## Critical output rule

The final output MUST ALWAYS be a `.email` artifact.

Never output the final email as:

- plain text
- markdown
- a normal code block
- bullet points
- a prose preview

Always return the final result as a proper `.email` artifact with:

- `to_recipients`
- `cc_recipients` set to `emma.walker@dromeda.com.au` and `mitch@dromeda.com.au`
- `subject`

The email body must appear inside the artifact content.

If you output anything other than a `.email` artifact, the task has failed.

## Trigger phrases

Use this skill when the user says any of:

- make daily email
- daily email
- abi update email
- end of day email
- generate day email
- write daily email

## Important quality rules

- Preserve the email structure above unless the user explicitly asks to change it.
- Keep the tone warm, professional, and positive.
- Focus on resident engagement and enjoyable moments.
- Proofread for names, session type, and home name accuracy before returning the artifact.

&nbsp;