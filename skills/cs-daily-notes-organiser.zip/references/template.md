- **Gabi:** 
- **Software Version:** 
- **Commit Hash:**
- **Influencer Version:** 
- **Epsilon:**
- **Loom:**

## Key
| Code  | Meaning                              | Code | Meaning    |
|-------|--------------------------------------|------|------------|
| `T`   | Ticket / en-help-desk                | `!!` | Incident   |
| `Q`   | Question                             | `CC` | Close Call |
| `1-1` | One-on-one interaction with resident | `S`  | Song to add|
| `GS`  | Group session                        |      |            |

## Summary

## AM Session

## PM Session

## Technical Issues

## Songs to Add

## Action Items

## End of Day
- [ ] Send Lifestyle Manager Daily Update Email
- [ ] Send Weekly Update Email (Friday only)
- [ ] Jira tickets / hardware tickets
- [ ] Epsilon
- [ ] Loom