# cs-daily-notes-organiser — Examples

---

## Example 1

### Input (raw notes)

```
park hill, wednesday

am
- music group 10-10:45, about 6 residents. played la bamba and what a wonderful world. lots of clapping and singing along, betty was tapping her feet the whole time. betty asked if we could get "my way" by frank sinatra - don't think we have it
- 1:1 with tom rm 8, 11:15-11:45. navy stories. played beyond the sea and sailing by rod stewart. got a bit emotional but in a nice way
- storage room was locked when we arrived, had to get key from reception

pm
- 1:1 helen rm 17, 2-2:30. lots of chat about her grandkids. played edelweiss and que sera sera. very chatty today
- trivia group 3-3:30, 5 residents, helen joined again. robert was leaning forward answering every question, vera was laughing a lot
- need to follow up about helen's room visit request for thursdays
```

### Output

```markdown
- **Gabi:** gabi-23-prod
- **Software Version:** v19.1.0
- **Commit Hash:**
- **Influencer Version:** au-prod
- **Epsilon:**
- **Loom:**

## Key
| Code  | Meaning                              | Code | Meaning    |
|-------|--------------------------------------|------|------------|
| `T`   | Ticket / en-help-desk                | `!!` | Incident   |
| `Q`   | Question                             | `CC` | Close Call |
| `1-1` | One-on-one interaction with resident | `S`  | Song to add|
| `GS`  | Group session                        |      |            |

## Summary
- Positive AM music group — La Bamba got good engagement from residents
- Tom (rm 8) had a meaningful 1:1 centred on navy memories; emotional but in a good way
- Helen (rm 17) was very engaged across both PM sessions and joined trivia after her 1:1
- Betty requested My Way by Frank Sinatra — needs sourcing
- Follow up on Helen's Thursday room visit request

## AM Session

GS | Music and Movement, 10:00 – 10:45
- Residents present: 6 — Betty and 5 others
- Residents actively engaged: 6
- Widespread clapping and singing along throughout; Betty was tapping her feet for the full session.
- Songs: La Bamba – Los Lobos; What a Wonderful World – Louis Armstrong
- **Intervention class:** TBC

S | "My Way" – "Frank Sinatra"

1-1 | Tom, Room 8, 11:15 – 11:45
- **Songs Played:** Beyond the Sea – Bobby Darin; Sailing – Rod Stewart.
- Talked about his time in the navy — very engaged and reflective. Got a little emotional but in a good way.
- **Intervention class:** TBC

L | Storage room access
- Room was locked on arrival.
- Obtained key from reception — worth flagging for future visits.

## PM Session

1-1 | Helen, Room 17, 14:00 – 14:30
- **Songs Played:** Edelweiss – Julie Andrews; Que Sera Sera – Doris Day.
- Very chatty today — talked at length about her grandkids. High energy and positive throughout.
- **Intervention class:** TBC

GS | Trivia, 15:00 – 15:30
- Residents present: 5 — Robert, Vera, Helen and 2 others
- Residents actively engaged: 4
- Robert leaned forward answering every question — very switched on. Vera was laughing throughout. Helen rejoined after her 1:1.
- **Intervention class:** TBC

## Technical Issues
None

## Songs to Add
- **S |** "My Way" – "Frank Sinatra"

## Action Items
- [ ] Source My Way by Frank Sinatra for Abi — raise Jira if not already on Abi
- [ ] Follow up on Helen's (rm 17) request to have Abi visit her room on Thursdays
- [ ] Flag locked storage room access with lifestyle coordinator

## End of Day
- [ ] Send Lifestyle Manager Daily Update Email
- [ ] Send Weekly Update Email (Friday only)
- [ ] Jira tickets / hardware tickets
- [ ] Epsilon
- [ ] Loom
```

---

## Example 2

### Input (raw notes)

```
park hill, thursday

am
- tai chi group 9:30-10, 8 residents. everyone joined in the movements, margaret was really following the instructor closely. abi's mic wasn't picking up at 9:45 - tapped the tablet to try to fix but didn't work, had to skip the voice prompt section
- 1:1 with george rm 12, 10:30-11. talked about cricket. played waltzing matilda and true blue. george was clapping along and humming. class B - needed to prompt george to look at abi a couple of times but otherwise she held the session well

pm
- music group 2-2:45, 6 residents. played moon river and somewhere over the rainbow. doris was swaying the whole time, june was mouthing the words. abi's screen froze at 2:20, had to restart - lost about 3 minutes. came back fine after reboot
- 1:1 with june rm 3, 3-3:30. very quiet today, seemed tired. played danny boy. just sat with her, didn't push for chat. class C - june wasn't engaging with abi at all so I had to step in and redirect a few times to keep things going
- staff asked if abi could play during sunday morning breakfast going forward
```

### Output

```markdown
- **Gabi:** gabi-23-prod
- **Software Version:** v19.1.0
- **Commit Hash:**
- **Influencer Version:** au-prod
- **Epsilon:**
- **Loom:**

## Key
| Code  | Meaning                              | Code | Meaning    |
|-------|--------------------------------------|------|------------|
| `T`   | Ticket / en-help-desk                | `!!` | Incident   |
| `Q`   | Question                             | `CC` | Close Call |
| `1-1` | One-on-one interaction with resident | `S`  | Song to add|
| `GS`  | Group session                        |      |            |

## Summary
- AM tai chi group well attended — Margaret closely following instructor throughout
- George (rm 12) very engaged 1:1 — cricket chat, clapping and humming along
- Doris and June both visibly moved during PM music group
- June (rm 3) quiet and tired in her 1:1 — worth noting for next visit
- Two tech issues today: mic failure during tai chi, screen freeze during PM music group — both need tickets
- Staff raised Sunday breakfast session request — needs follow-up

## AM Session

**GS |** Tai Chi, 09:30 – 10:00
- Residents present: 8 — Margaret and 7 others
- Residents actively engaged: 8
- Everyone joined in the movements; Margaret was closely following the instructor throughout.
- **T |** 09:45 — Abi mic not picking up; tapping tablet did not resolve — voice prompt section skipped. Raise ticket in #cs-internal-help-desk / Jira.
- **Intervention class:** TBC

**1-1 |** George, Room 12, 10:30 – 11:00
- **Songs Played:** Waltzing Matilda – Slim Dusty; True Blue – John Williamson.
- Talked about his love of cricket — animated and enthusiastic throughout.
- Was clapping along and humming to both songs.
- **Intervention class:** B
  - needed to prompt george to look at abi a couple of times but otherwise she held the session well

## PM Session

**GS |** Music Group, 14:00 – 14:45
- Residents present: 6 — Doris, June and 4 others
- Residents actively engaged: 6
- Doris was swaying throughout; June was mouthing the words to both songs.
- **T |** 14:20 — Abi screen froze mid-session; required full restart, ~3 min lost. Came back fine after reboot. Raise ticket in #cs-internal-help-desk / Jira.
- Songs: Moon River – Audrey Hepburn; Somewhere Over the Rainbow – Judy Garland
- **Intervention class:** TBC

**1-1 |** June, Room 3, 15:00 – 15:30
- **Songs Played:** Danny Boy – Traditional.
- Quiet and subdued today — seemed tired. Kept interaction gentle, did not push for conversation.
- Worth checking in on her wellbeing next visit.
- **Intervention class:** C
  - june wasn't engaging with abi at all so I had to step in and redirect a few times to keep things going

**Q |** Staff asked: "Can Abi be scheduled to play during Sunday morning breakfast going forward?" Ask in #cs-internal-help-desk.

## Technical Issues
- **T |** 09:45 — Abi mic not picking up; voice prompt section skipped, tablet tap did not resolve
- **T |** 14:20 — Abi screen froze during PM music group; required restart, ~3 min lost

## Songs to Add
None

## Action Items
- [ ] Raise Jira ticket for mic failure at 09:45 — mic not picking up, unresolved during session
- [ ] Raise Jira ticket for screen freeze at 14:20 — required restart mid music group
- [ ] Follow up on staff request for Sunday morning breakfast session — ask in #cs-internal-help-desk
- [ ] Check in on June (rm 3) next visit — quiet and tired today

## End of Day
- [ ] Send Lifestyle Manager Daily Update Email
- [ ] Send Weekly Update Email (Friday only)
- [ ] Jira tickets / hardware tickets
- [ ] Epsilon
- [ ] Loom