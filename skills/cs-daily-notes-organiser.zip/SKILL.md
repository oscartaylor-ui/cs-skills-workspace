---
name: cs-daily-notes-organiser
description: Organises raw daily Customer Success (CS) field notes into a formatted markdown Daily Notes document following Andromeda Robotics' standard template. Trigger when the user provides raw, unformatted notes from an Abi session at a facility (e.g. Park Hill) and asks to clean, tidy, format, organise, synthesise, clean up, or turn them into daily notes.
---
# cs-daily-notes-organiser

## Workflow

### Step 1 — Read the template

Load `references/template.md` to understand the required output structure before doing any formatting work.

### Step 2 — Parse the raw notes

Read the raw input carefully and identify:

- Header metadata (Gabi name, software version, commit hash, influencer version, Epsilon link, Loom link) — use only what the user has provided; leave fields blank if absent. For **Gabi**, **Software Version**, and **Influencer Version**, check Glean Memory first and pre-fill if found — only override with a value from the raw notes if the user has explicitly provided one.
- Which entries belong to AM Session vs PM Session. If the user has not separated them, make a reasonable split based on any time cues; if no cues exist, put all entries under AM Session.
- Each distinct event type: **T**, **1-1**, **GS**, **S**, **Q**, **!!**, **CC**, **L**.

### Step 3 — Format each entry

Apply these rules to every identified event.

**Key constraints:**

- Do **not** invent times, names, or room numbers — omit them if not present. Always include timestamps when present in the raw notes.
- Do **not** add explanations or meta-commentary in the output.
- Songs played go under the session they were played in, not as a standalone block (unless they were a standalone song request).

---

#### **T |** Ticket — inline placement

**WHEN:** A technical issue observed during the session that needs a Jira or en-help-desk ticket raised. **FORMAT:** Place as a **bullet point within the bullet list of the GS, 1-1, or L entry it occurred in**, at the chronological point it happened — this gives engineers visibility of what was happening just before and after the issue.

**Timestamp rule (hard requirement):** If a timestamp is present in the raw notes (e.g. `T | 13.35`, `t 2:10`, `~14:20`), it **must** appear in the formatted output immediately after `T |`, before the description. Never drop or move a timestamp. If no timestamp is present, omit it.

```
- **T |** HH.MM — one line summary of what happened and any immediate action taken
- **T |** one line summary (no timestamp — only when genuinely absent from raw notes)
```

---

#### **S |** Song to Add

**WHEN:** A song is requested or needed but not on Abi. **FORMAT:** **S |** "Song Name" – "Artist"

One line per song. If there is any uncertainty about whether the song is already on Abi, still list it as an **S |** entry — do not add a **Q |** entry for it.

---

#### **Q |** Question

**WHEN:** Any question from staff, resident, exec, family member, or note taker that needs follow-up. **FORMAT (staff question):** **Q |** Staff asked: "insert question here." Ask in #cs-internal-help-desk.

**FORMAT (note taker's own question):** **Q |** Note taker asked: "insert question here." Ask in #cs-internal-help-desk.

---

#### **1-1 |** One-on-one with Resident

**WHEN:** A 1:1 resident session. **FORMAT:** **1-1 |** Resident Name, Room XXX, HH:MM – HH:MM

If room unknown, omit room. If times unknown, omit times. Then bullets:

- **Songs Played** (sub-list): `Song Name – Artist;` per line, last entry ends with `.`
- 1–3 bullets summarising what was talked about and how it went.
- **Intervention class** line (see Intervention Class rule below).

---

#### **GS |** Group Session

**WHEN:** Any group session (tai chi, music, trivia, etc.). **FORMAT:** **GS |** [type of group session], HH:MM – HH:MM

Omit duration if times unknown. Then bullets:

- Residents present: N — Name1, Name2, Name3, … (**required**: list every resident named in the raw notes, even in passing; if the total count is higher than the number of named residents, append "and [X] others" to account for the full count)
- Residents actively engaged: N
- Brief summary of activities and highlights
- *(Optional)* Songs: Song A – Artist; Song B – Artist; …
- **Intervention class** line (see Intervention Class rule below).

---

#### **!! |** Incident

**WHEN:** Actual safety/behaviour incident (e.g. Abi arm caught in walker, resident hitting Abi, Abi falling, Abi moving on her own). **FORMAT:** **!! |** short title

Bullets with: time, who/what involved, what happened, immediate action taken, follow-up needed (if any).

---

#### **CC |** Close Call

**WHEN:** Near-miss (resident almost bumps Abi, pretends to run into her, etc.). **FORMAT:** **CC |** short title

Bullets with: time, who/what involved, what almost happened, how it was avoided.

---

#### **L |** Logistics *(optional)*

**WHEN:** Access, storage, schedule, staff coordination. **FORMAT:** **L |** short title

1–3 bullets with key logistical details.

---

#### **Intervention Class** — all 1-1, GS, and corridor interactions

Every **1-1**, **GS**, and corridor interaction entry must include an intervention class line as the **last bullet** of the entry. Apply these rules strictly:

- **If the facilitator's raw notes explicitly state an intervention class (A, B, C, or D)**, place it as the last bullet formatted as:
  `- **Intervention class:** [A/B/C/D]`
  If the facilitator also provided comments or reasoning explaining why they chose that class, include those verbatim as an indented sub-bullet immediately below — **never omit them**:
  `  - [Facilitator's comment, preserved exactly as written]`
- **If no intervention class is present in the raw notes**, add the following as the last bullet instead:
  `- **Intervention class:** TBC`
- **Never determine, infer, or assign an intervention class yourself.** The CS facilitator is the only person who can classify an interaction. If a class is absent, always write TBC — do not make a judgement based on the content of the notes.

For reference only (do not use to infer a class):

- **Class A** — CS staff member does not intervene at all; Abi runs the interaction autonomously.
- **Class B** — Minor intervention; small/occasional support, Abi remains the main driver.
- **Class C** — Moderate intervention; noticeable support provided multiple times, Abi still meaningfully involved.
- **Class D** — Major intervention; CS staff actively talking to Abi in front of residents, with little/no direct resident engagement with Abi.

---

### Step 4 — Generate the SUMMARY block

After formatting all session entries, write a concise `## Summary` block at the **top** of the document (above AM Session). It should:

- Be 3–6 bullet points
- Highlight the most notable resident interactions, any incidents or close calls, song requests, and open questions
- Be written for a lifestyle coordinator to skim quickly

### Step 5 — Populate end-of-day sections

After PM Session, populate these three sections from today's notes:

- **## Technical Issues** — roll-up of all **T |** entries from the AM/PM sessions; repeat each as a bullet using **T |** format, preserving the timestamp exactly as it appeared in the session entry: `**T |** HH.MM — brief description`
- **## Songs to Add** — bullet list using **S |** format: `**S |** "Song Name" – "Artist"`
- **## Action Items** — checkbox list of to-dos and follow-ups arising from today. **Do not include tickets to raise or songs to add here** — these are already captured in the Technical Issues and Songs to Add sections above. Only include other actionable items (e.g. questions to follow up on, logistical tasks, staff follow-ups).

If nothing applies to a section, write `None` beneath the heading.

### Step 6 — Produce the artifact

Output the finished notes as a `.md` artifact following `references/template.md`.

For worked examples of input → output, refer to `references/examples.md`.